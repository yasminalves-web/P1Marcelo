import '../data/usuario_mock_store.dart';
import '../models/usuario_model.dart';

class SignupViewModel {
  final UsuarioMockStore _store = UsuarioMockStore();

  /// Retorna null se OK, ou uma mensagem de erro
  String? cadastrar(String nome, String email, String senha) {
    if (_store.emailJaCadastrado(email.trim())) {
      return 'E-mail já cadastrado';
    }
    _store.adicionarUsuario(
      UsuarioModel(nome: nome.trim(), email: email.trim(), senha: senha),
    );
    return null;
  }

  String? validarNome(String? value) {
    if (value == null || value.trim().isEmpty) return 'Informe o nome';
    return null;
  }

  String? validarEmail(String? value) {
    if (value == null || value.trim().isEmpty) return 'Informe o e-mail';
    if (!value.contains('@')) return 'E-mail inválido';
    return null;
  }

  String? validarSenha(String? value) {
    if (value == null || value.isEmpty) return 'Informe a senha';
    if (value.length < 6) return 'Senha deve ter ao menos 6 caracteres';
    return null;
  }

  String? validarConfirmacao(String? value, String senha) {
    if (value == null || value.isEmpty) return 'Confirme a senha';
    if (value != senha) return 'As senhas não coincidem';
    return null;
  }
}
