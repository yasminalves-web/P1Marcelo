# Flutter App — Splash, Login, Cadastro e Home

## Descrição

Aplicativo Flutter com autenticação simulada em memória, desenvolvido como atividade avaliativa.

---

## Arquitetura adotada

O projeto segue uma separação de responsabilidades inspirada no padrão **MVVM (Model-View-ViewModel)**:

```
lib/
├── main.dart                        # Ponto de entrada e definição de rotas
└── app/
    ├── models/
    │   └── usuario_model.dart       # Representa os dados do usuário
    ├── data/
    │   └── usuario_mock_store.dart  # Singleton que armazena usuários em memória
    ├── viewmodels/
    │   ├── splash_viewmodel.dart    # Lógica da splash (temporizador + navegação)
    │   ├── login_viewmodel.dart     # Autenticação e validação do login
    │   └── signup_viewmodel.dart   # Cadastro e validação do formulário
    └── views/
        ├── splash_page.dart         # Tela inicial com loading
        ├── login_page.dart          # Tela de login
        ├── signup_page.dart         # Tela de cadastro
        └── home_page.dart           # Tela home pós-login
```

---

## Fluxo do aplicativo

1. **Splash** → exibe por 3 segundos e navega automaticamente para o Login
2. **Login** → valida e-mail e senha buscando na lista em memória
3. **Cadastro** → adiciona novo usuário à lista; volta ao login após sucesso
4. **Home** → exibe ícone e mensagem de boas-vindas com o nome do usuário; botão de logout

---

## Armazenamento em memória

A classe `UsuarioMockStore` usa o padrão **Singleton** para garantir que a mesma lista de usuários seja compartilhada entre as telas de cadastro e login durante toda a execução do app.

```dart
// Exemplo de uso
final store = UsuarioMockStore(); // sempre retorna a mesma instância

store.adicionarUsuario(usuario);          // chamado no cadastro
store.buscarUsuario(email, senha);        // chamado no login
```

Um usuário padrão já vem cadastrado para testes:
- **E-mail:** `admin@teste.com`
- **Senha:** `123456`

---

## Model utilizado

```dart
class UsuarioModel {
  final String nome;
  final String email;
  final String senha;
}
```

---

## Como rodar

```bash
flutter pub get
flutter run
```
