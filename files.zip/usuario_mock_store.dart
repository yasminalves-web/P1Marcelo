import '../models/usuario_model.dart';

class UsuarioMockStore {
  // Singleton
  static final UsuarioMockStore _instance = UsuarioMockStore._internal();
  factory UsuarioMockStore() => _instance;
  UsuarioMockStore._internal();

  // Lista de usuários em memória
  final List<UsuarioModel> _usuarios = [
    // Usuário mockado inicial para facilitar testes
    UsuarioModel(nome: 'Admin', email: 'admin@teste.com', senha: '123456'),
  ];

  List<UsuarioModel> get usuarios => List.unmodifiable(_usuarios);

  void adicionarUsuario(UsuarioModel usuario) {
    _usuarios.add(usuario);
  }

  UsuarioModel? buscarUsuario(String email, String senha) {
    try {
      return _usuarios.firstWhere(
        (u) => u.email == email && u.senha == senha,
      );
    } catch (_) {
      return null;
    }
  }

  bool emailJaCadastrado(String email) {
    return _usuarios.any((u) => u.email == email);
  }
}
